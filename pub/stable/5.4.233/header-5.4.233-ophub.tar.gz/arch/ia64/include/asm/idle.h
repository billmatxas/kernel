/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_IA64_IDLE_H
#define _ASM_IA64_IDLE_H

static inline void enter_idle(void) { }
static inline void exit_idle(void) { }

#endif /* _ASM_IA64_IDLE_H */
