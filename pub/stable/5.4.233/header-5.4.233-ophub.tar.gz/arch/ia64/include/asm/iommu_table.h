/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_IA64_IOMMU_TABLE_H
#define _ASM_IA64_IOMMU_TABLE_H

#define IOMMU_INIT_POST(_detect)

#endif /* _ASM_IA64_IOMMU_TABLE_H */
