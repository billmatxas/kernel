/* SPDX-License-Identifier: GPL-2.0 */
#include <xen/arm/page-coherent.h>
