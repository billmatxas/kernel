/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __H8300_TLB_H__
#define __H8300_TLB_H__

#include <asm-generic/tlb.h>

#endif
