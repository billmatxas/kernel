/* SPDX-License-Identifier: GPL-2.0 */

#ifndef __ASM_LINKAGE_H
#define __ASM_LINKAGE_H

#define __ALIGN		.align 4
#define __ALIGN_STR	".align 4"

#endif
