#ifndef __XTENSA_AUXVEC_H
#define __XTENSA_AUXVEC_H

#endif
