/* SPDX-License-Identifier: GPL-2.0 */
// Copyright (C) 2005-2017 Andes Technology Corporation

#define __ARCH_WANT_SYS_CLONE

#include <uapi/asm/unistd.h>
