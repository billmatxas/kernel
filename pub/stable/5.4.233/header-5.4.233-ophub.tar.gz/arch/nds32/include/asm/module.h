/* SPDX-License-Identifier: GPL-2.0 */
// Copyright (C) 2005-2017 Andes Technology Corporation

#ifndef _ASM_NDS32_MODULE_H
#define _ASM_NDS32_MODULE_H

#include <asm-generic/module.h>

#define MODULE_ARCH_VERMAGIC	"NDS32v3"

#endif /* _ASM_NDS32_MODULE_H */
