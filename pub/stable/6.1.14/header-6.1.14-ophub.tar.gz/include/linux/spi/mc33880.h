/* SPDX-License-Identifier: GPL-2.0 */
#ifndef LINUX_SPI_MC33880_H
#define LINUX_SPI_MC33880_H

struct mc33880_platform_data {
	/* number assigned to the first GPIO */
	unsigned	base;
};

#endif

